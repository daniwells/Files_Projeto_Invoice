// mfcpch.cpp : source file that includes just the standard includes
//      elist.pch will be the pre-compiled header
//      mfcpch.obj will contain the pre-compiled type information

#include          "mfcpch.h"     //precompiled headers
